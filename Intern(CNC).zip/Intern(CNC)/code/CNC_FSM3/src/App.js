import './App.css';
import Todo from './components/todo';

const App=()=>{
  return (
    <div>
      <Todo/>
    </div>
  )
}

export default App;